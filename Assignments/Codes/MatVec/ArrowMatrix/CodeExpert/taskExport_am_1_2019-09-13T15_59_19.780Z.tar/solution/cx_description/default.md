# Problem 2-1: Arrow matrix-vector mutliplication

> For the task description of this exercise, please refer to [NCSE19_Problems.pdf](
https://www.sam.math.ethz.ch/~grsam/NCSE19/HOMEWORK/NCSE19_Problems.pdf). 

> Open "ArrowMatrix_functions.hpp" and fill in the missing code in between the delimiters `// START` and `// END` according to the instructions preceded by `// TO DO:`.

> To view plots, click the "Files" button on the toolbar at the bottom of the page.