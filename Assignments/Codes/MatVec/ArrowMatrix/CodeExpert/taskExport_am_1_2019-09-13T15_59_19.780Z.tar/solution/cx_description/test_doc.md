


# Tests of ArrowMatrix_functions.hpp
> There is no test for this exercise as zzzzz_test_runner.cpp does not work if there are plots created in the program.