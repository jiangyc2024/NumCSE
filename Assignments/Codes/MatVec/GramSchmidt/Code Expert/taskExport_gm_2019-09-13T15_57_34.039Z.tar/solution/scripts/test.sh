#!/bin/bash

# run (call run script)
bash "${WORKDIR}/scripts/run.sh"